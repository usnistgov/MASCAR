package NIST.NISTGripper.impl;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.contribution.installation.InstallationAPIProvider;
import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.domain.script.ScriptWriter;

import com.ur.urcap.api.domain.io.DigitalIO;
import com.ur.urcap.api.domain.io.IO;
import com.ur.urcap.api.domain.io.IOModel;
import com.ur.urcap.api.domain.io.ModbusIO;


public class NISTGripperInstallationNodeContribution implements InstallationNodeContribution{

	private final InstallationAPIProvider apiProvider;
	private final NISTGripperInstallationNodeView view;
	private DataModel model;
	//private final UndoRedoManager undoRedoManager;
	
	private static final String OUTPUT_KEY = "output";
	private static final String DURATION_KEY = "duration";
	
	private static final Integer DEFAULT_OUTPUT = 0;
	private static final int DEFAULT_DURATION = 1;

	private static IOHelper helper;
	
	public NISTGripperInstallationNodeContribution(InstallationAPIProvider apiProvider, DataModel model, NISTGripperInstallationNodeView view) {

		this.apiProvider = apiProvider;
		this.view = view;
		this.model = model;
		//this.undoRedoManager = this.apiProvider.getInstallationAPI().getUndoRedoManager();
		this.helper = new IOHelper(apiProvider.getInstallationAPI().getIOModel());
	}
	
	public void onOutputSelection(final Integer output) 
	{
		//undoRedoManager.recordChanges(new UndoableChanges() 
		//{
		//	
		//	@Override
		//	public void executeChanges() 
		//	{
		//		model.set(OUTPUT_KEY, output);
		//	}
		//});
	}
	

	public void openGripperTest() {
		DigitalIO digitalOut1= helper.getSpecificDigitalIO("digital_out[0]");
		digitalOut1.setValue(true);
	}

	public void closeGripperTest() {
		DigitalIO digitalOut1= helper.getSpecificDigitalIO("digital_out[0]");
		digitalOut1.setValue(false);

	}


	public void onDurationSelection(final int duration) 
	{
		//undoRedoManager.recordChanges(new UndoableChanges() {
		//	
		//	@Override
		//	public void executeChanges() {
		//		model.set(DURATION_KEY, duration);
		//	}
		//});
	}
	
	private Integer getOutput() {
		return model.get(OUTPUT_KEY, DEFAULT_OUTPUT);
	}
	
	public Boolean getOpen()
	{
		return view.getOpen();
	}

	private int getDuration() {
		return model.get(DURATION_KEY, DEFAULT_DURATION);
	}
	
	private Integer[] getOutputItems() {
		Integer[] items = new Integer[8];
		for(int i = 0; i<8; i++) {
			items[i] = i;
		}
		return items;
	}
	
	@Override
	public void openView() {
		view.setIOComboBoxItems(getOutputItems());
		
		view.setIOComboBoxSelection(getOutput());
		view.setDurationSlider(getDuration());
	}

	@Override
	public void closeView() {
	}

	public boolean isDefined() {
		return true;
	}

	@Override
	public void generateScript(ScriptWriter writer) 
	{
		if (getOpen())
		{
			writer.appendLine("set_standard_digital_out(0,True)");
		}
		else
		{
			writer.appendLine("set_standard_digital_out(0,False)");
		}
		writer.sleep(getDuration());
	}

}