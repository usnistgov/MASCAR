package NIST.NISTGripper.impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit test for simple App.
 */
class AppTest {

	/**
	 * Rigourous Test :-)
	 */
	@Test
	void testApp() {
		assertTrue( true );
	}
}
