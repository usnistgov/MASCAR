package NIST.NISTGripper.impl;

import java.util.Locale;

import com.ur.urcap.api.contribution.ViewAPIProvider;
import com.ur.urcap.api.contribution.program.ContributionConfiguration;
import com.ur.urcap.api.contribution.program.CreationContext;
import com.ur.urcap.api.contribution.program.ProgramAPIProvider;
import com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService;
import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.data.DataModel;

public class NISTGripperProgramNodeService implements SwingProgramNodeService<NISTGripperProgramNodeContribution, NISTGripperProgramNodeView>{

	@Override
	public String getId() {
		return "NISTGripperNode";
	}

	@Override
	public void configureContribution(ContributionConfiguration configuration) {
		configuration.setChildrenAllowed(false);
	}

	@Override
	public String getTitle(Locale locale) {
		return "Gripper Actuation";
	}

	@Override
	public NISTGripperProgramNodeView createView(ViewAPIProvider apiProvider) {
		SystemAPI systemAPI = apiProvider.getSystemAPI();
		Style style = systemAPI.getSoftwareVersion().getMajorVersion() >= 5 ? new V5Style() : new V3Style();

		return new NISTGripperProgramNodeView(apiProvider);
	}

	@Override
	public NISTGripperProgramNodeContribution createNode(ProgramAPIProvider apiProvider, NISTGripperProgramNodeView view,
			DataModel model, CreationContext context) {
		return new NISTGripperProgramNodeContribution(apiProvider, view, model);
	}

}