package NIST.NISTGripper.impl;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import com.ur.urcap.api.contribution.installation.swing.SwingInstallationNodeService;
import com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService;

public class Activator implements BundleActivator {
	@Override
	public void start(final BundleContext context) {
		context.registerService(SwingInstallationNodeService.class, new NISTGripperInstallationNodeService(), null);
		context.registerService(SwingProgramNodeService.class, new NISTGripperProgramNodeService(), null);
	}

	@Override
	public void stop(BundleContext context) {
		// Nothing to stop
	}
}
