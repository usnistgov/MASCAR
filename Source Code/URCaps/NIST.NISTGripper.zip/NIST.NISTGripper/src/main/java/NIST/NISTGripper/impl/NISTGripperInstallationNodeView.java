package NIST.NISTGripper.impl;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


import com.ur.urcap.api.contribution.installation.swing.SwingInstallationNodeView;

public class NISTGripperInstallationNodeView implements SwingInstallationNodeView<NISTGripperInstallationNodeContribution>{

	private final Style style;
	
	public NISTGripperInstallationNodeView(Style style) {
		this.style = style;
	}
	
	private JComboBox<Integer> ioComboBox = new JComboBox<Integer>();
	private JRadioButton closeButton = new JRadioButton("Close Gripper");
	private JRadioButton openButton = new JRadioButton("Open Gripper");
	private ButtonGroup G = new ButtonGroup();
	private JSlider durationSlider = new JSlider();
	
	@Override
	public void buildUI(JPanel panel, final NISTGripperInstallationNodeContribution installationNode) {
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		panel.add(createDescription("Actuating gripper on digital output 0:"));
		panel.add(createSpacer(5));
		//panel.add(createIOComboBox(ioComboBox, installationNode));
		panel.add(createOpenButton(openButton, installationNode));
		panel.add(createCloseButton(closeButton, installationNode));
		G.add(openButton);
		G.add(closeButton);
		//panel.add(createDescription("Set duration actuation wait:"));
		//panel.add(createSpacer(5));
		//panel.add(createDurationSlider(durationSlider, 0, 10, installationNode));
	}
	
	public void setIOComboBoxItems(Integer[] items) {
		ioComboBox.removeAllItems();
		ioComboBox.setModel(new DefaultComboBoxModel<Integer>(items));
	}
	
	public void setIOComboBoxSelection(Integer item) {
		ioComboBox.setSelectedItem(item);
	}
	
	public void setDurationSlider(int value) {
		durationSlider.setValue(value);
	}
	
	private Box createDescription(String desc) {
		Box box = Box.createHorizontalBox();
		box.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		JLabel label = new JLabel(desc);
		
		box.add(label);
		
		return box;
	}
	

	private Box createOpenButton(final JRadioButton butt, final NISTGripperInstallationNodeContribution installationNode) {
		Box box = Box.createHorizontalBox();
		box.setAlignmentX(Component.LEFT_ALIGNMENT);
	
		butt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				installationNode.openGripperTest();
			}
		});
		
		box.add(createSpacer(10));
		box.add(butt);
		
		return box;
	}


	private Box createCloseButton(final JRadioButton butt, final NISTGripperInstallationNodeContribution installationNode) {
		Box box = Box.createHorizontalBox();
		box.setAlignmentX(Component.LEFT_ALIGNMENT);
	
		butt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				installationNode.closeGripperTest();
			}
		});
		
		box.add(createSpacer(10));
		box.add(butt);
		
		return box;
	}




	private Box createIOComboBox(final JComboBox<Integer> combo,
			final NISTGripperInstallationNodeContribution installationNode) {
		Box box = Box.createHorizontalBox();
		box.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		JLabel label = new JLabel(" digital_out ");
		
		combo.setPreferredSize(new Dimension(104, 30));
		combo.setMaximumSize(combo.getPreferredSize());
		
		combo.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					installationNode.onOutputSelection((Integer) e.getItem());
				}
			}
		});
		
		box.add(label);
		box.add(combo);
		
		return box;
	}

	public Boolean getOpen()
	{
		return openButton.isSelected();
	}

	private Box createDurationSlider(final JSlider slider, int min, int max,
			final NISTGripperInstallationNodeContribution installationNode) {
		Box box = Box.createHorizontalBox();
		box.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		slider.setMinimum(min);
		slider.setMaximum(max);
		slider.setOrientation(JSlider.HORIZONTAL);
		
		slider.setPreferredSize(new Dimension(275, 30));
		slider.setMaximumSize(slider.getPreferredSize());
		
		final JLabel value = new JLabel(Integer.toString(slider.getValue())+" s");
		
		slider.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				int newValue = slider.getValue();
				value.setText(Integer.toString(newValue)+" s");
				installationNode.onDurationSelection(newValue);
			}
		});
		
		box.add(slider);
		box.add(value);
		
		return box;
	}
	
	private Component createSpacer(int height) {
		return Box.createRigidArea(new Dimension(0, height));
	}

}